﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class AdminPage : Form
    {
       public int id;
        
        public AdminPage(int id)
        {
            InitializeComponent();
            this.id = id;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginPage a = new LoginPage();
            a.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EditTicketClerkPage a = new EditTicketClerkPage(this);
            a.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EditStationPage a = new EditStationPage(this);
            a.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            EditTrainPage a = new EditTrainPage(this);
            a.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Information a = new Information(this);
            a.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
