﻿namespace Admin
{
    partial class Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.buttonSellsList = new System.Windows.Forms.Button();
            this.buttonRefundList = new System.Windows.Forms.Button();
            this.buttonCustomer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.button1.Location = new System.Drawing.Point(331, 351);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 44);
            this.button1.TabIndex = 0;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSellsList
            // 
            this.buttonSellsList.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.buttonSellsList.Location = new System.Drawing.Point(331, 164);
            this.buttonSellsList.Name = "buttonSellsList";
            this.buttonSellsList.Size = new System.Drawing.Size(120, 45);
            this.buttonSellsList.TabIndex = 1;
            this.buttonSellsList.Text = "Sells List";
            this.buttonSellsList.UseVisualStyleBackColor = false;
            this.buttonSellsList.Click += new System.EventHandler(this.buttonSellsList_Click);
            // 
            // buttonRefundList
            // 
            this.buttonRefundList.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.buttonRefundList.Location = new System.Drawing.Point(331, 247);
            this.buttonRefundList.Name = "buttonRefundList";
            this.buttonRefundList.Size = new System.Drawing.Size(120, 41);
            this.buttonRefundList.TabIndex = 2;
            this.buttonRefundList.Text = "RefundList";
            this.buttonRefundList.UseVisualStyleBackColor = false;
            this.buttonRefundList.Click += new System.EventHandler(this.buttonRefundList_Click);
            // 
            // buttonCustomer
            // 
            this.buttonCustomer.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.buttonCustomer.Location = new System.Drawing.Point(331, 57);
            this.buttonCustomer.Name = "buttonCustomer";
            this.buttonCustomer.Size = new System.Drawing.Size(120, 48);
            this.buttonCustomer.TabIndex = 3;
            this.buttonCustomer.Text = "Customer";
            this.buttonCustomer.UseVisualStyleBackColor = false;
            this.buttonCustomer.Click += new System.EventHandler(this.buttonCustomer_Click);
            // 
            // Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(753, 450);
            this.Controls.Add(this.buttonCustomer);
            this.Controls.Add(this.buttonRefundList);
            this.Controls.Add(this.buttonSellsList);
            this.Controls.Add(this.button1);
            this.Name = "Information";
            this.Text = "Information";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonSellsList;
        private System.Windows.Forms.Button buttonRefundList;
        private System.Windows.Forms.Button buttonCustomer;
    }
}