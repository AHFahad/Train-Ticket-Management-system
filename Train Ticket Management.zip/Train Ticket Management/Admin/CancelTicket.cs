﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class CancelTicket : Form
    {
        SqlConnection con;
        enum ticketStatus { cancelled,active}
        TicketClerkPage t;
        public CancelTicket(TicketClerkPage t)
        {
            InitializeComponent();
            this.t = t;

            con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            string[] status = new string[3];
            status[0] = "";
            status[1]= ticketStatus.cancelled.ToString();
            status[2]= ticketStatus.active.ToString();
            comboBoxTicketStatus.DataSource =status;



        }

        private void button1_Click(object sender, EventArgs e)
        {

            #region get ticket value 


            textBoxCustomerName.Text = "";
            textBoxCustomerPhoneNumber.Text = "";
            textBoxC_id.Text = "";
            textBoxTicketPrice.Text = "";
            comboBoxTicketStatus.Text = "";
          


            string sql = "select C_name,C_phone,Customer.C_id,price,Ti_status from Ticket   inner join Customer on Ticket.C_id=Customer.C_id inner join Train on Ticket.Tr_serialNo=Train.Tr_serialNo  where Ti_serialNo= " + textBoxTicketNumber.Text  ;
           // SqlDataReader myReader;

            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                try
                {
                    
                    con.Open();

                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        
                        textBoxCustomerName.Text = dr[0].ToString();
                        textBoxCustomerPhoneNumber.Text = dr[1].ToString();
                        textBoxC_id.Text = dr[2].ToString();
                        textBoxTicketPrice.Text = dr[3].ToString();
                        comboBoxTicketStatus.Text = int.Parse(dr[4].ToString()) == 1 ? ticketStatus.active.ToString() : ticketStatus.cancelled.ToString();
                        
                    }
                    dr.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("some thing went wrong. can not get tickets from database");
                }



                con.Close();

            }



            #endregion




        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void buttonTicketCancel_Click(object sender, EventArgs e)
        {

            #region set tiket status to zero or cancel


            string sql2 = "UPDATE Ticket SET Ti_status=0";
            using (SqlCommand cmd = new SqlCommand(sql2, con))
            {

                con.Open();

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                // MessageBox.Show("insert succesfully");
                con.Close();
            }




            #endregion


            #region add to refund list

            string sql3 = "INSERT INTO Refunds_list( Ti_serialNo,c_id,Amount ) VALUES(@param1,@param2,@param3)";
            using (SqlCommand cmd = new SqlCommand(sql3, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxTicketNumber.Text);
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = int.Parse(textBoxC_id.Text);
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(textBoxTicketPrice.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Ticket cancel succesfull !!!");


                con.Close();
            }




            #endregion
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            t.Show();
            this.Hide();
        }

        private void CancelTicket_Load(object sender, EventArgs e)
        {

        }
    }
}
