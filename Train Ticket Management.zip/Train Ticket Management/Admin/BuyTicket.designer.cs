﻿namespace Admin
{
    partial class BuyTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewStations = new System.Windows.Forms.DataGridView();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBoxStations = new System.Windows.Forms.GroupBox();
            this.comboBoxToStation = new System.Windows.Forms.ComboBox();
            this.comboBoxFromStation = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.textBoxCustomerName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxPhoneNumber = new System.Windows.Forms.TextBox();
            this.buttonConfirmTicket = new System.Windows.Forms.Button();
            this.textBoxTicketPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonCreateTrainDatesShedule = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxNumberOfTickets = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxTotalCost = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStations)).BeginInit();
            this.groupBoxStations.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(677, 392);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(245, 20);
            this.dateTimePicker1.TabIndex = 15;
            // 
            // dataGridViewStations
            // 
            this.dataGridViewStations.BackgroundColor = System.Drawing.Color.ForestGreen;
            this.dataGridViewStations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStations.Location = new System.Drawing.Point(3, 297);
            this.dataGridViewStations.Name = "dataGridViewStations";
            this.dataGridViewStations.Size = new System.Drawing.Size(546, 228);
            this.dataGridViewStations.TabIndex = 14;
            this.dataGridViewStations.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewStations_CellDoubleClick);
            this.dataGridViewStations.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridViewStations_MouseDoubleClick);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.ForestGreen;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.PaleGoldenrod;
            this.btnSearch.Location = new System.Drawing.Point(592, 457);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(161, 44);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // groupBoxStations
            // 
            this.groupBoxStations.Controls.Add(this.comboBoxToStation);
            this.groupBoxStations.Controls.Add(this.comboBoxFromStation);
            this.groupBoxStations.Controls.Add(this.label4);
            this.groupBoxStations.Controls.Add(this.label3);
            this.groupBoxStations.Controls.Add(this.label2);
            this.groupBoxStations.Location = new System.Drawing.Point(577, 297);
            this.groupBoxStations.Name = "groupBoxStations";
            this.groupBoxStations.Size = new System.Drawing.Size(345, 78);
            this.groupBoxStations.TabIndex = 10;
            this.groupBoxStations.TabStop = false;
            // 
            // comboBoxToStation
            // 
            this.comboBoxToStation.FormattingEnabled = true;
            this.comboBoxToStation.Location = new System.Drawing.Point(234, 22);
            this.comboBoxToStation.Name = "comboBoxToStation";
            this.comboBoxToStation.Size = new System.Drawing.Size(111, 21);
            this.comboBoxToStation.TabIndex = 4;
            // 
            // comboBoxFromStation
            // 
            this.comboBoxFromStation.FormattingEnabled = true;
            this.comboBoxFromStation.Location = new System.Drawing.Point(68, 25);
            this.comboBoxFromStation.Name = "comboBoxFromStation";
            this.comboBoxFromStation.Size = new System.Drawing.Size(108, 21);
            this.comboBoxFromStation.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.ForestGreen;
            this.label4.Location = new System.Drawing.Point(195, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "To";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.ForestGreen;
            this.label2.Location = new System.Drawing.Point(12, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "From";
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.ForestGreen;
            this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.ForeColor = System.Drawing.Color.PaleGoldenrod;
            this.buttonBack.Location = new System.Drawing.Point(23, 246);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(256, 34);
            this.buttonBack.TabIndex = 16;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxCustomerName
            // 
            this.textBoxCustomerName.Location = new System.Drawing.Point(174, 63);
            this.textBoxCustomerName.Name = "textBoxCustomerName";
            this.textBoxCustomerName.Size = new System.Drawing.Size(375, 20);
            this.textBoxCustomerName.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.ForestGreen;
            this.label6.Location = new System.Drawing.Point(20, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 16);
            this.label6.TabIndex = 18;
            this.label6.Text = "Customer Name :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.ForestGreen;
            this.label7.Location = new System.Drawing.Point(20, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "Phone Number :";
            // 
            // textBoxPhoneNumber
            // 
            this.textBoxPhoneNumber.Location = new System.Drawing.Point(174, 107);
            this.textBoxPhoneNumber.Name = "textBoxPhoneNumber";
            this.textBoxPhoneNumber.Size = new System.Drawing.Size(375, 20);
            this.textBoxPhoneNumber.TabIndex = 20;
            // 
            // buttonConfirmTicket
            // 
            this.buttonConfirmTicket.BackColor = System.Drawing.Color.ForestGreen;
            this.buttonConfirmTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfirmTicket.ForeColor = System.Drawing.Color.PaleGoldenrod;
            this.buttonConfirmTicket.Location = new System.Drawing.Point(308, 246);
            this.buttonConfirmTicket.Name = "buttonConfirmTicket";
            this.buttonConfirmTicket.Size = new System.Drawing.Size(241, 34);
            this.buttonConfirmTicket.TabIndex = 21;
            this.buttonConfirmTicket.Text = "Confirm Ticket";
            this.buttonConfirmTicket.UseVisualStyleBackColor = false;
            this.buttonConfirmTicket.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBoxTicketPrice
            // 
            this.textBoxTicketPrice.Location = new System.Drawing.Point(174, 21);
            this.textBoxTicketPrice.Name = "textBoxTicketPrice";
            this.textBoxTicketPrice.Size = new System.Drawing.Size(375, 20);
            this.textBoxTicketPrice.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.ForestGreen;
            this.label8.Location = new System.Drawing.Point(20, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 16);
            this.label8.TabIndex = 23;
            this.label8.Text = "Ticket Price :";
            // 
            // buttonCreateTrainDatesShedule
            // 
            this.buttonCreateTrainDatesShedule.BackColor = System.Drawing.Color.ForestGreen;
            this.buttonCreateTrainDatesShedule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateTrainDatesShedule.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCreateTrainDatesShedule.ForeColor = System.Drawing.Color.PaleGoldenrod;
            this.buttonCreateTrainDatesShedule.Location = new System.Drawing.Point(759, 457);
            this.buttonCreateTrainDatesShedule.Name = "buttonCreateTrainDatesShedule";
            this.buttonCreateTrainDatesShedule.Size = new System.Drawing.Size(163, 44);
            this.buttonCreateTrainDatesShedule.TabIndex = 24;
            this.buttonCreateTrainDatesShedule.Text = "Create Train schedule";
            this.buttonCreateTrainDatesShedule.UseVisualStyleBackColor = false;
            this.buttonCreateTrainDatesShedule.Click += new System.EventHandler(this.buttonCreateTrainDate_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.ForestGreen;
            this.label9.Location = new System.Drawing.Point(589, 398);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Select Date :";
            // 
            // comboBoxNumberOfTickets
            // 
            this.comboBoxNumberOfTickets.FormattingEnabled = true;
            this.comboBoxNumberOfTickets.Location = new System.Drawing.Point(175, 151);
            this.comboBoxNumberOfTickets.Name = "comboBoxNumberOfTickets";
            this.comboBoxNumberOfTickets.Size = new System.Drawing.Size(374, 21);
            this.comboBoxNumberOfTickets.TabIndex = 26;
            this.comboBoxNumberOfTickets.SelectedIndexChanged += new System.EventHandler(this.comboBoxNumberOfTickets_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.ForestGreen;
            this.label10.Location = new System.Drawing.Point(20, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 16);
            this.label10.TabIndex = 27;
            this.label10.Text = "Numbers of Tickets";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.ForestGreen;
            this.label11.Location = new System.Drawing.Point(20, 211);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 16);
            this.label11.TabIndex = 28;
            this.label11.Text = "Total Cost :";
            // 
            // textBoxTotalCost
            // 
            this.textBoxTotalCost.Location = new System.Drawing.Point(175, 201);
            this.textBoxTotalCost.Name = "textBoxTotalCost";
            this.textBoxTotalCost.Size = new System.Drawing.Size(374, 20);
            this.textBoxTotalCost.TabIndex = 29;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.groupBoxStations);
            this.panel1.Controls.Add(this.buttonBack);
            this.panel1.Controls.Add(this.buttonConfirmTicket);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.textBoxTotalCost);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.comboBoxNumberOfTickets);
            this.panel1.Controls.Add(this.buttonCreateTrainDatesShedule);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.textBoxPhoneNumber);
            this.panel1.Controls.Add(this.dataGridViewStations);
            this.panel1.Controls.Add(this.textBoxTicketPrice);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.textBoxCustomerName);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 528);
            this.panel1.TabIndex = 30;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Admin.Properties.Resources.images__1_evfgrtv1;
            this.pictureBox1.Location = new System.Drawing.Point(577, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(354, 259);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // BuyTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(974, 552);
            this.Controls.Add(this.panel1);
            this.Name = "BuyTicket";
            this.Text = "BuyTicket";
            this.Load += new System.EventHandler(this.BuyTicket_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStations)).EndInit();
            this.groupBoxStations.ResumeLayout(false);
            this.groupBoxStations.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridViewStations;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBoxStations;
        private System.Windows.Forms.ComboBox comboBoxToStation;
        private System.Windows.Forms.ComboBox comboBoxFromStation;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.TextBox textBoxCustomerName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxPhoneNumber;
        private System.Windows.Forms.Button buttonConfirmTicket;
        private System.Windows.Forms.TextBox textBoxTicketPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonCreateTrainDatesShedule;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxNumberOfTickets;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxTotalCost;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}