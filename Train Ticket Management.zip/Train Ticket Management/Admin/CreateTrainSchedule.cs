﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class CreateTrainSchedule : Form
    {
        ComboBox from;
        ComboBox to;
        SqlConnection con;
        public CreateTrainSchedule(ComboBox from,ComboBox to)
        {
            InitializeComponent();
            this.from = from;
            this.to = to;
            con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();

            view();
        }

        private void CreateTrainSchedule_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void view()
        {

            string sql = "select Train.Tr_serialNo,Tr_name,s.startTime,e.endTime,ss.S_name,es.S_name from Train inner join Train_Station_StartTime s on Train.Tr_serialNo=s.Tr_serialNo inner join Train_Station_EndTime e on e.Tr_serialNo=Train.Tr_serialNo inner join Station ss on ss.S_serialNo=s.S_serialNo inner join Station es on es.S_serialNo=e.S_serialNo where ss.S_name='"+from.Text.Trim().ToString()+"' and es.S_name='"+to.Text.Trim().ToString()+"' and Train.Tr_status="+1;
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                con.Open();

                try
                {



                    SqlDataReader DR = cmd.ExecuteReader();
                    if (DR.HasRows)
                    {


                        BindingSource source = new BindingSource();
                        source.DataSource = DR;


                        dataGridView1.DataSource = source;

                    }
                    else
                    {
                        MessageBox.Show("No train found!!!");
                        
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                con.Close();
            }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                textBoxTrainId.Text = row.Cells[0].Value.ToString();
              
            }
        }

        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if (textBoxTrainId.Text != "")
            {
                #region ceate shidul by trian id

                string sql6 = "INSERT INTO Total_Booked_Seat_By_Date(Train_SeatBooked_date,total_booked_seat,Tr_serialNo) VALUES(@param1,@param2,@param3) ";
                using (SqlCommand cmd = new SqlCommand(sql6, con))
                {

                    con.Open();



                    cmd.Parameters.Add("@param1", SqlDbType.Date).Value = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                    cmd.Parameters.Add("@param2", SqlDbType.Int).Value = 0;//initail booked seat 0

                    cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(textBoxTrainId.Text);



                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                   


                    con.Close();
                }


                #endregion


                MessageBox.Show("new shediul has been Created.");
                this.Close();
            }

            else
            {
                MessageBox.Show("Please Select a Train");
            }
           
        }
    }
}
