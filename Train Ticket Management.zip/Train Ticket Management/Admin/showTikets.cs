﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class showTikets : Form
    {
        int cid;
        public showTikets(int cid )
        {
            InitializeComponent();
            this.cid = cid;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void showTikets_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();

            string sql = "select Ti_serialNo,seatNo from Ticket where C_id="+cid;

            SqlCommand command = new SqlCommand(sql, con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            BindingSource source = new BindingSource();
            source.DataSource = DR;


            dataGridView1.DataSource = source;


            con.Close();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
