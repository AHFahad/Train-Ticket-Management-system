﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    enum status { cancelled,active}
    public partial class BuyTicket : Form
    {
        int numberoftickets;
        int cid;
        int TrainSerialNo;
        int price;
        int seatCapacity;
        int totalbookedseat;
        string bookedDate;
        int trtoid;

        SqlConnection con;
        TicketClerkPage t;
        public BuyTicket(TicketClerkPage t)
        {
            InitializeComponent();

             con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            this.t = t;
            string[] search = new string[3];
            search[0] = "station";
            search[1] = "train name";
            //comboBoxSearchBye.DataSource = search;

            searchStation();

            

        }
       
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //serach button


            string sql = "select Train.Tr_serialNo,Tr_name,price,total_booked_seat,seatCapacity,Train_SeatBooked_Date,startTime,endTime,Train_Station_StartTime.S_serialNo,Train_Station_EndTime.S_serialNo,s.S_name ,e.S_name, TrTo_id from Train inner join Total_Booked_Seat_By_Date on Total_Booked_Seat_By_Date.Tr_serialNo=Train.Tr_serialNo inner join Train_Station_StartTime on Train_Station_StartTime.Tr_serialNo=Train.Tr_serialNo inner join Train_Station_EndTime on Train_Station_EndTime.Tr_serialNo=Train.Tr_serialNo inner join Station s on s.S_serialNo=Train_Station_StartTime.S_serialNo inner join station e on  e.S_serialNo=Train_Station_EndTime.S_serialNo where s.S_name='" + comboBoxFromStation.Text.Trim() + "' and e.S_name='" + comboBoxToStation.Text.Trim() + "' and Train_SeatBooked_Date='" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "'";


            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                con.Open();

                try
                {

                    


                    
                   
                        SqlDataReader DR = cmd.ExecuteReader();
                    if (DR.HasRows)
                    {
                        


                        BindingSource source = new BindingSource();
                        source.DataSource = DR;


                        dataGridViewStations.DataSource = source;

                    }
                    else
                    {
                        MessageBox.Show("no train found!!!");
                    }
                    
                }
                catch (Exception ex)
                {
                   
                }
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            t.Show();
        }

        private void comboBoxSearchBye_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (comboBoxSearchBye.Text == "station")
            //{
            //    groupBoxStations.Visible = true;
            //    groupBoxName.Visible = false;

            //}
            //else if(comboBoxSearchBye.Text=="train name")
            //{
            //    groupBoxStations.Visible = false;
            //    groupBoxName.Visible = true;
            //}



        }



        public  void searchStation()
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();


            string sql = "select * from Station where S_status=1 ";
            SqlDataReader myReader;
            
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                try
                {

                    con.Open();
                    myReader = cmd.ExecuteReader();
                    while (myReader.Read())
                    {
                        string name = myReader.GetString(1);
                        comboBoxFromStation.Items.Add(name);
                        comboBoxToStation.Items.Add(name);
                    }



                }
                catch(Exception ex)
                {
                    MessageBox.Show("some thing went wrong can not get stations from database");
                }


                con.Close();
            }
        }

        private void BuyTicket_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //confirm button
            numberoftickets = seatCapacity - totalbookedseat;
            if (numberoftickets > 5)
            {
                numberoftickets = 5;
            }


            comboBoxNumberOfTickets.Items.Clear();
            for (int i = 1; i <= numberoftickets; i++)
            {
               
                comboBoxNumberOfTickets.Items.Add(i);
            }

            if (comboBoxNumberOfTickets.Text == "")
            {
                MessageBox.Show("select number of tickets");
            }

           else if (totalbookedseat+int.Parse(comboBoxNumberOfTickets.Text) > seatCapacity)
            {
                MessageBox.Show("sorry cant buy ticket");
            }
            else
            {

                #region start



                if (textBoxPhoneNumber.Text.Trim() != "" && textBoxCustomerName.Text != "" && comboBoxNumberOfTickets.Text != "")
                {






                    #region insert customer ditails

                    string sql2 = "INSERT INTO Customer(C_name,C_phone) VALUES(@param1,@param2) ";
                    using (SqlCommand cmd = new SqlCommand(sql2, con))
                    {

                        con.Open();



                        cmd.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = textBoxCustomerName.Text.Trim();

                        cmd.Parameters.Add("@param2", SqlDbType.VarChar, 50).Value = textBoxPhoneNumber.Text.Trim();




                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        // MessageBox.Show("customer ditails insert  succesfully");


                        con.Close();
                    }

                    #endregion


                    #region get customer id

                    string sql3 = "select C_id from Customer order by C_id desc";
                    //int cid = 0;
                    using (SqlCommand cmd = new SqlCommand(sql3, con))
                    {

                        con.Open();




                        SqlDataReader DR = cmd.ExecuteReader();
                        if (DR.Read())
                        {
                            cid = int.Parse(DR[0].ToString());

                        }
                        //  MessageBox.Show("customer id retrived  succesfully " + cid);


                        con.Close();
                    }



                    #endregion


                    for (int i = 0; i < int.Parse(comboBoxNumberOfTickets.Text); i++)
                    {
                        #region update train seat avalable

                        string sql = "update Total_Booked_Seat_By_Date set total_booked_seat=@param1 where TrTo_id=@param2 ";
                        using (SqlCommand cmd = new SqlCommand(sql, con))
                        {

                            con.Open();

                            totalbookedseat = 1 + totalbookedseat;

                            cmd.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = totalbookedseat;

                            cmd.Parameters.Add("@param2", SqlDbType.Int).Value = trtoid;




                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                            // MessageBox.Show("seat update succesfully");


                            con.Close();
                        }


                        #endregion

                        #region add ticket ditails

                        string sql4 = "INSERT INTO Ticket(seatNo,C_id,Tm_serialNo,Tr_serialNo,Ti_status) VALUES(@param1,@param2,@param3,@param4,@param5) ";
                        using (SqlCommand cmd = new SqlCommand(sql4, con))
                        {

                            con.Open();



                            cmd.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = SeatNoGenarator.SeatNo(totalbookedseat);

                            cmd.Parameters.Add("@param2", SqlDbType.Int).Value = cid;

                            cmd.Parameters.Add("@param3", SqlDbType.Int).Value = t.id;

                            cmd.Parameters.Add("@param4", SqlDbType.Int).Value = TrainSerialNo;
                            cmd.Parameters.Add("@param5", SqlDbType.Int).Value =int.Parse("1");// status  1 means active

                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                            //   MessageBox.Show("ticket ditails insert  succesfully");


                            con.Close();
                        }



                        #endregion

                        #region get ticket id
                        string sql5 = "select Ti_serialNo from Ticket order by Ti_serialNo desc";
                        int tid = 0;
                        using (SqlCommand cmd = new SqlCommand(sql5, con))
                        {

                            con.Open();




                            SqlDataReader DR = cmd.ExecuteReader();
                            if (DR.Read())
                            {
                                tid = int.Parse(DR[0].ToString());

                            }
                            // MessageBox.Show("ticket id retrived  succesfully " + tid);


                            con.Close();
                        }

                        #endregion

                        #region insert into sells list

                        string sql6 = "INSERT INTO Sells_List(Ti_serialNo,C_id,Cost) VALUES(@param1,@param2,@param3) ";
                        using (SqlCommand cmd = new SqlCommand(sql6, con))
                        {

                            con.Open();



                            cmd.Parameters.Add("@param1", SqlDbType.Int).Value = tid;

                            cmd.Parameters.Add("@param2", SqlDbType.Int).Value = cid;

                            cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(textBoxTicketPrice.Text);



                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                            //   MessageBox.Show("ticket ditails insert  succesfully");


                            con.Close();
                        }


                        #endregion

                    }


                    new showTikets(cid).Show();



                }
                else
                {
                    MessageBox.Show("Please insert Customer Name,Number of tickets and Phone number.");
                }

                #endregion

            }

        }

        private void dataGridViewStations_MouseDoubleClick(object sender, MouseEventArgs e)
        {
           


        }

        private void dataGridViewStations_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //get all the necesary data for ticket buy
            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dataGridViewStations.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                TrainSerialNo = int.Parse(row.Cells[0].Value.ToString());
                textBoxTicketPrice.Text = row.Cells[2].Value.ToString();
              
                totalbookedseat = int.Parse(row.Cells[3].Value.ToString());
                seatCapacity =int.Parse (row.Cells[4].Value.ToString());
                trtoid = int.Parse(row.Cells[12].Value.ToString());

                if (totalbookedseat >= seatCapacity)
                {
                    MessageBox.Show("No seat avalable");
                }
                else
                {
                    numberoftickets = seatCapacity - totalbookedseat;
                    if (numberoftickets > 5)
                    {
                        numberoftickets = 5;
                    }


                    comboBoxNumberOfTickets.Items.Clear();
                    for (int i = 1; i <= numberoftickets; i++)
                    {
                        
                        comboBoxNumberOfTickets.Items.Add(i);
                    }
                }

            }
        }

        private void buttonCreateTrainDate_Click(object sender, EventArgs e)
        {
            //creat train shidul buton
            CreateTrainSchedule ts = new CreateTrainSchedule(comboBoxFromStation,comboBoxToStation);
            ts.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxNumberOfTickets_SelectedIndexChanged(object sender, EventArgs e)
        {
            int x = int.Parse(comboBoxNumberOfTickets.Text) * int.Parse(textBoxTicketPrice.Text);
            textBoxTotalCost.Text = x.ToString();
        }
    }
}
