﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Admin
{
    class Database
    {
        public Boolean CheckAdmin(int id, string password)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();
            string sql = "SELECT  A_serialNo, A_password FROM Admin WHERE(A_serialNo = '" + id + "') AND(A_password = '" + password.Trim() + "')";

            SqlCommand commmand = new SqlCommand(sql, con);
            con.Open();

            var check = commmand.ExecuteScalar();

            if (check != null)
            {
                return true;
            }
            else return false;
        }


        public Boolean CheckTicketClerk(int id, string password, int status)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();
            string sql = "SELECT  Tm_serialNo, Tm_status,tm_Password FROM Ticket_Man WHERE(Tm_serialNo = '" + id + "') AND(Tm_Password = '" + password.Trim() + "') AND(Tm_status = '" + status + "')";

            SqlCommand commmand = new SqlCommand(sql, con);
            con.Open();

            var check = commmand.ExecuteScalar();

            if (check != null)
            {
                return true;
            }
            else return false;
        }
    }
}
