﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Admin
{
    public partial class EditStationPage : Form
    {
        enum status { Active, Inactive }
        string[] ab = new string[2];

        AdminPage ad;
        public EditStationPage(AdminPage ad)
        {
            InitializeComponent();
            this.ad = ad;
            ab[0] = status.Active.ToString();
            ab[1] = status.Inactive.ToString();

            comboBoxS_status.DataSource = ab;
        }

        private void edit_Station1_Load(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
          
            ad.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();


            con.ConnectionString = GetString.getconnectionString();


            string sql = "INSERT INTO Station(S_name,location,A_serialNo,S_status) VALUES(@param1,@param2,@param3,@param4)";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = textBoxS_name.Text;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = textBoxS_location.Text;
                

                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = ad.id;
               
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = comboBoxS_status.Text.ToString() == status.Active.ToString() ? 1 : 0;




                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                MessageBox.Show("insert succesfully");

                con.Close();
            }

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBoxS_location_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            SqlCommand command = new SqlCommand("select * from Station ", con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            BindingSource source = new BindingSource();
            source.DataSource = DR;


            dataGridViewS.DataSource = source;


            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();


            con.ConnectionString = GetString.getconnectionString();




            string sql = "UPDATE Station SET S_Name=@param1,location=@param2,A_serialNo=@param3,S_status=@param4 where S_serialNo=@param5 ";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = textBoxS_name.Text;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = textBoxS_location.Text;
                

                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = ad.id;

                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = comboBoxS_status.Text.ToString() == status.Active.ToString() ? 1 : 0;

                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = int.Parse(textBoxS_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("update succesfully");


                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            #region delete starttime table


            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();


            string sql1 = "delete from Train_Station_StartTime where S_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql1, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxS_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();


                con.Close();
            }

            #endregion

            #region delete endtime table

            string sql2 = "delete from Train_Station_EndTime where S_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql2, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxS_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
               // MessageBox.Show("delete succesfully");


                con.Close();
            }


            #endregion

            #region delete station table

           // SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();

            string sql = "delete from Station where S_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxS_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");


                con.Close();
            }

            #endregion
        }

        private void dataGridViewS_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //textBoxS_name.Text = dataGridViewS.SelectedRows[0].Cells[1].Value.ToString();
            //textBoxS_location.Text = dataGridViewS.SelectedRows[0].Cells[2].Value.ToString();

            //textBoxS_serialNo.Text = dataGridViewS.SelectedRows[0].Cells[0].Value.ToString();
            //comboBoxS_status.Text = dataGridViewS.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void EditStationPage_Load(object sender, EventArgs e)
        {

        }

        private void dataGridViewS_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridViewS.Rows[e.RowIndex];

                textBoxS_name.Text = row.Cells[1].Value.ToString();
                textBoxS_location.Text = row.Cells[2].Value.ToString();

                textBoxS_serialNo.Text = row.Cells[0].Value.ToString();
                comboBoxS_status.Text = row.Cells[4].Value.ToString();

            }

            
        }
    }
}
