﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class Information : Form
    {
        AdminPage ad;
        public Information(AdminPage ad)
        {
            InitializeComponent();
            this.ad = ad;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
           // AdminPage a = new AdminPage();
            ad.Show();
        }

        private void buttonCustomer_Click(object sender, EventArgs e)
        {
            new InformationView("select * from Customer", "Customer List").Show();
        }

        private void buttonSellsList_Click(object sender, EventArgs e)
        {
            new InformationView("select * from Sells_List", "Sells List").Show();
        }

        private void buttonRefundList_Click(object sender, EventArgs e)
        {
            new InformationView("select * from Refunds_List", "Refund List").Show();
        }
    }
}
