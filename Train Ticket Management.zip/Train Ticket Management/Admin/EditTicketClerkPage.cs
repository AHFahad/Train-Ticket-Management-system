﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Admin
{
    public partial class EditTicketClerkPage : Form
    {
        enum status {Active,Inactive}
        string[] ab= new string[2];


     





        AdminPage ad;
        public EditTicketClerkPage(AdminPage ad)
        {
            InitializeComponent();
            this.ad = ad;

             ab[0]=status.Active.ToString();
             ab[1]=status.Inactive.ToString();

            comboBoxTC_status.DataSource=ab;
        }

        private void edit_TicketClark1_Load(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
           // AdminPage a = new AdminPage();
            ad.Show();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            
            SqlConnection con = new SqlConnection();

            
            con.ConnectionString = GetString.getconnectionString();


            string sql = "INSERT INTO Ticket_Man(Tm_name,Tm_email,Tm_phone,Tm_password,Tm_address,Tm_dateOfBirth,A_serialNo,Tm_status) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7,@param8)";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                
                con.Open();

               
                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = textBoxTC_name.Text;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = textBoxTC_email.Text;
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = textBoxTC_phone.Text;
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = textBoxTC_password.Text;
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = textBoxTC_address.Text;
                cmd.Parameters.Add("@param6", SqlDbType.Date).Value = dateTimePickerTC_dob.Value.Date;
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = ad.id;
                cmd.Parameters.Add("@param8", SqlDbType.Int).Value = comboBoxTC_status.Text.ToString() == status.Active.ToString() ? 1 : 0;




                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                MessageBox.Show("insert succesfully");

                con.Close();
            }

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxTC_status_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            SqlCommand command = new SqlCommand("select * from Ticket_Man ", con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            BindingSource source = new BindingSource();
            source.DataSource = DR;


            dataGridViewTm.DataSource = source;


            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();


            con.ConnectionString = GetString.getconnectionString();




            string sql = "UPDATE Ticket_Man SET Tm_Name=@param1,Tm_email=@param2,Tm_phone=@param3,Tm_password=@param4,Tm_address=@param5,Tm_dateOfBirth=@param6,A_serialNo=@param7,Tm_status=@param8 where Tm_serialNo=@param9 ";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();

                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = textBoxTC_name.Text;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar).Value = textBoxTC_email.Text;
                cmd.Parameters.Add("@param3", SqlDbType.VarChar).Value = textBoxTC_phone.Text;
                cmd.Parameters.Add("@param4", SqlDbType.VarChar).Value = textBoxTC_password.Text;
                cmd.Parameters.Add("@param5", SqlDbType.VarChar).Value = textBoxTC_address.Text;
                cmd.Parameters.Add("@param6", SqlDbType.Date).Value = dateTimePickerTC_dob.Value.Date;
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = ad.id;
                cmd.Parameters.Add("@param8", SqlDbType.Int).Value = comboBoxTC_status.Text.ToString() == status.Active.ToString() ? 1 : 0;


                cmd.Parameters.Add("@param9", SqlDbType.Int).Value = int.Parse(textBoxTC_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("update succesfully");


                con.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = GetString.getconnectionString();

            #region delete sells list by ticketid
            #endregion

            #region delete refund list by ticketid
            #endregion

            #region delete ticket by ticket man or ticket clerk

            string sql = "delete from Ticket where Tm_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxTC_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");


                con.Close();
            }


            #endregion


            #region delete ticket clerk





            string sql2 = "delete from Ticket_Man where Tm_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql2, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxTC_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");


                con.Close();
            }

            #endregion
        }

        private void dataGridViewTm_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //textBoxTC_serialNo.Text = dataGridViewTm.SelectedRows[0].Cells[0].Value.ToString();
            //textBoxTC_name.Text = dataGridViewTm.SelectedRows[0].Cells[1].Value.ToString();
            //textBoxTC_email.Text = dataGridViewTm.SelectedRows[0].Cells[2].Value.ToString();

            //textBoxTC_phone.Text = dataGridViewTm.SelectedRows[0].Cells[3].Value.ToString();

            //textBoxTC_password.Text = dataGridViewTm.SelectedRows[0].Cells[4].Value.ToString();
            //textBoxTC_address.Text = dataGridViewTm.SelectedRows[0].Cells[5].Value.ToString();
            //dateTimePickerTC_dob.Text = dataGridViewTm.SelectedRows[0].Cells[6].Value.ToString();


            //comboBoxTC_status.Text = dataGridViewTm.SelectedRows[0].Cells[8].Value.ToString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridViewTm_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridViewTm.Rows[e.RowIndex];



                textBoxTC_serialNo.Text = row.Cells[0].Value.ToString();
                textBoxTC_name.Text = row.Cells[1].Value.ToString();
                textBoxTC_email.Text = row.Cells[2].Value.ToString();

                textBoxTC_phone.Text = row.Cells[3].Value.ToString();

                textBoxTC_password.Text = row.Cells[4].Value.ToString();
                textBoxTC_address.Text = row.Cells[5].Value.ToString();
                dateTimePickerTC_dob.Text = row.Cells[6].Value.ToString();


                comboBoxTC_status.Text = row.Cells[8].Value.ToString();



            }
        }

        private void EditTicketClerkPage_Load(object sender, EventArgs e)
        {

        }
    }
}
