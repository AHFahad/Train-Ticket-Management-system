﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class InformationView : Form
    {
        string v;
        string name;
        public InformationView(String v,string name)
        {
            InitializeComponent();
            this.v = v;
            this.name = name;


        }

        private void InformationView_Load(object sender, EventArgs e)
        {
            label1.Text = name;
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            SqlCommand command = new SqlCommand(v, con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            BindingSource source = new BindingSource();
            source.DataSource = DR;


            dataGridViewList.DataSource = source;


            con.Close();
        }

        private void dataGridViewList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
