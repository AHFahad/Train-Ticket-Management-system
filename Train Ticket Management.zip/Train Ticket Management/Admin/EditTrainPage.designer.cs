﻿namespace Admin
{
    partial class EditTrainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTR_price = new System.Windows.Forms.TextBox();
            this.textBoxTR_seatCapacity = new System.Windows.Forms.TextBox();
            this.textBoxTR_name = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxTR_status = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridViewTR = new System.Windows.Forms.DataGridView();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxTR_serialNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBoxTR_ss = new System.Windows.Forms.ComboBox();
            this.comboBoxTR_es = new System.Windows.Forms.ComboBox();
            this.dateTimePickerTR_st = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTR_et = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewS = new System.Windows.Forms.DataGridView();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTR)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewS)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Train Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Seat Capacity:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 2;
            // 
            // textBoxTR_price
            // 
            this.textBoxTR_price.Location = new System.Drawing.Point(116, 190);
            this.textBoxTR_price.Name = "textBoxTR_price";
            this.textBoxTR_price.Size = new System.Drawing.Size(200, 20);
            this.textBoxTR_price.TabIndex = 3;
            this.textBoxTR_price.TextChanged += new System.EventHandler(this.textBoxTR_price_TextChanged);
            // 
            // textBoxTR_seatCapacity
            // 
            this.textBoxTR_seatCapacity.Location = new System.Drawing.Point(116, 158);
            this.textBoxTR_seatCapacity.Name = "textBoxTR_seatCapacity";
            this.textBoxTR_seatCapacity.Size = new System.Drawing.Size(200, 20);
            this.textBoxTR_seatCapacity.TabIndex = 3;
            this.textBoxTR_seatCapacity.TextChanged += new System.EventHandler(this.textBoxTR_seatCapacity_TextChanged);
            // 
            // textBoxTR_name
            // 
            this.textBoxTR_name.Location = new System.Drawing.Point(116, 132);
            this.textBoxTR_name.Name = "textBoxTR_name";
            this.textBoxTR_name.Size = new System.Drawing.Size(200, 20);
            this.textBoxTR_name.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(30, 120);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 24);
            this.button1.TabIndex = 4;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Admin.Properties.Resources.download__3_;
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(339, 122);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(41, 401);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "BACK";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(10, 295);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 15);
            this.label6.TabIndex = 2;
            this.label6.Text = "Ending Station:";
            // 
            // comboBoxTR_status
            // 
            this.comboBoxTR_status.FormattingEnabled = true;
            this.comboBoxTR_status.Location = new System.Drawing.Point(116, 223);
            this.comboBoxTR_status.Name = "comboBoxTR_status";
            this.comboBoxTR_status.Size = new System.Drawing.Size(200, 21);
            this.comboBoxTR_status.TabIndex = 5;
            this.comboBoxTR_status.SelectedIndexChanged += new System.EventHandler(this.comboBoxTR_status_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(182, 398);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 26);
            this.button2.TabIndex = 6;
            this.button2.Text = "INSERT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // dataGridViewTR
            // 
            this.dataGridViewTR.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridViewTR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTR.Location = new System.Drawing.Point(341, 2);
            this.dataGridViewTR.Name = "dataGridViewTR";
            this.dataGridViewTR.Size = new System.Drawing.Size(457, 220);
            this.dataGridViewTR.TabIndex = 7;
            this.dataGridViewTR.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTR_CellContentClick);
            this.dataGridViewTR.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTR_CellDoubleClick);
            this.dataGridViewTR.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridViewTR_MouseDoubleClick);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(341, 219);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(457, 36);
            this.button4.TabIndex = 8;
            this.button4.Text = "SHOW TRAINS INFORMATION";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textBoxTR_serialNo);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(570, 261);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 177);
            this.panel1.TabIndex = 9;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(130, 121);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(68, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "DELETE";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(37, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Train Serial No:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(76, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Information";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(49, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Update Or Delete Train";
            // 
            // textBoxTR_serialNo
            // 
            this.textBoxTR_serialNo.Location = new System.Drawing.Point(144, 64);
            this.textBoxTR_serialNo.Name = "textBoxTR_serialNo";
            this.textBoxTR_serialNo.Size = new System.Drawing.Size(45, 20);
            this.textBoxTR_serialNo.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(12, 326);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "Starting Time:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(10, 261);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(99, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Starting Station:";
            this.label10.Click += new System.EventHandler(this.label3_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(12, 361);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "Ending Time:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(12, 195);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "Ticket Price:";
            this.label12.Click += new System.EventHandler(this.label3_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(10, 229);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 15);
            this.label13.TabIndex = 2;
            this.label13.Text = "Train Status:";
            // 
            // comboBoxTR_ss
            // 
            this.comboBoxTR_ss.FormattingEnabled = true;
            this.comboBoxTR_ss.Location = new System.Drawing.Point(116, 255);
            this.comboBoxTR_ss.Name = "comboBoxTR_ss";
            this.comboBoxTR_ss.Size = new System.Drawing.Size(200, 21);
            this.comboBoxTR_ss.TabIndex = 10;
            this.comboBoxTR_ss.SelectedIndexChanged += new System.EventHandler(this.comboBoxTR_ss_SelectedIndexChanged);
            // 
            // comboBoxTR_es
            // 
            this.comboBoxTR_es.FormattingEnabled = true;
            this.comboBoxTR_es.Location = new System.Drawing.Point(116, 289);
            this.comboBoxTR_es.Name = "comboBoxTR_es";
            this.comboBoxTR_es.Size = new System.Drawing.Size(200, 21);
            this.comboBoxTR_es.TabIndex = 10;
            // 
            // dateTimePickerTR_st
            // 
            this.dateTimePickerTR_st.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePickerTR_st.Location = new System.Drawing.Point(116, 321);
            this.dateTimePickerTR_st.Name = "dateTimePickerTR_st";
            this.dateTimePickerTR_st.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerTR_st.TabIndex = 11;
            // 
            // dateTimePickerTR_et
            // 
            this.dateTimePickerTR_et.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePickerTR_et.Location = new System.Drawing.Point(116, 356);
            this.dateTimePickerTR_et.Name = "dateTimePickerTR_et";
            this.dateTimePickerTR_et.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerTR_et.TabIndex = 11;
            // 
            // dataGridViewS
            // 
            this.dataGridViewS.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewS.Location = new System.Drawing.Point(343, 261);
            this.dataGridViewS.Name = "dataGridViewS";
            this.dataGridViewS.Size = new System.Drawing.Size(221, 154);
            this.dataGridViewS.TabIndex = 12;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(343, 409);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(221, 26);
            this.button6.TabIndex = 13;
            this.button6.Text = "SHOW STATIONS";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // EditTrainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.dataGridViewS);
            this.Controls.Add(this.dateTimePickerTR_et);
            this.Controls.Add(this.dateTimePickerTR_st);
            this.Controls.Add(this.comboBoxTR_es);
            this.Controls.Add(this.comboBoxTR_ss);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.dataGridViewTR);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.comboBoxTR_status);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBoxTR_name);
            this.Controls.Add(this.textBoxTR_seatCapacity);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBoxTR_price);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "EditTrainPage";
            this.Load += new System.EventHandler(this.EditTrainPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTR)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewS)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTR_price;
        private System.Windows.Forms.TextBox textBoxTR_seatCapacity;
        private System.Windows.Forms.TextBox textBoxTR_name;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxTR_status;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridViewTR;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxTR_serialNo;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBoxTR_ss;
        private System.Windows.Forms.ComboBox comboBoxTR_es;
        private System.Windows.Forms.DateTimePicker dateTimePickerTR_st;
        private System.Windows.Forms.DateTimePicker dateTimePickerTR_et;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridViewS;
        private System.Windows.Forms.Button button6;
    }
}