﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Admin
{

    public partial class EditTrainPage : Form
    {
        enum status { Active, Inactive }
        string[] ab = new string[2];
        AdminPage ad;
        public EditTrainPage(AdminPage ad)
        {
            InitializeComponent();
            Fillcombo();
            this.ad = ad;
            ab[0] = status.Active.ToString();
            ab[1] = status.Inactive.ToString();

            comboBoxTR_status.DataSource = ab;
        }



        void Fillcombo()
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = GetString.getconnectionString();


            string sql = "select * from Station";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader myReader;
            try
            {

                con.Open();
                myReader = cmd.ExecuteReader();


                while (myReader.Read())
                {

                    int stationSerialNo = myReader.GetInt32(0);
                    comboBoxTR_ss.Items.Add(stationSerialNo);
                    comboBoxTR_es.Items.Add(stationSerialNo);
                }
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }






        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            // AdminPage a = new AdminPage();
            ad.Show();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection();


            con.ConnectionString = GetString.getconnectionString();




            string sql = "UPDATE Train SET Tr_Name=@param1,price=@param2,seatCapacity=@param3,A_serialNo=@param4,Tr_status=@param5 where Tr_serialNo=@param6 ";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = textBoxTR_name.Text;
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = int.Parse(textBoxTR_price.Text);
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(textBoxTR_seatCapacity.Text);

                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = ad.id;

                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = comboBoxTR_status.Text.ToString() == status.Active.ToString() ? 1 : 0;

                cmd.Parameters.Add("@param6", SqlDbType.Int).Value = int.Parse(textBoxTR_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                


                con.Close();
            }



            SqlCommand command = new SqlCommand("select * from Train order by Tr_serialNo desc", con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();



            DR.Read();
            int id = int.Parse(DR[0].ToString());


            con.Close();




           
            string sql1 = "UPDATE Train_Station_EndTime SET endTime=@param1,Tr_serialNo=@param2,S_serialNo=@param3 where Tr_serialNo=@param4 ";
            using (SqlCommand cmd = new SqlCommand(sql1, con))
            {

                con.Open();

                cmd.Parameters.Add("@param1", SqlDbType.Time).Value = dateTimePickerTR_et.Value.ToString("HH:mm");
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = id;

                cmd.Parameters.Add("@param3", SqlDbType.Int).Value =int.Parse( comboBoxTR_es.Text);
                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = int.Parse(textBoxTR_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
              


                con.Close();
            }

             string sql2 = "UPDATE Train_Station_StartTime SET startTime=@param1,Tr_serialNo=@param2,S_serialNo=@param3 where Tr_serialNo=@param4 ";
            using (SqlCommand cmd = new SqlCommand(sql2, con))
            {

                con.Open();

                cmd.Parameters.Add("@param1", SqlDbType.Time).Value = dateTimePickerTR_st.Value.ToString("HH:mm");

                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = id;

                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(comboBoxTR_ss.Text);

                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = int.Parse(textBoxTR_serialNo.Text);

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("update succesfully");


                con.Close();
            }


        }

        private void EditTrainPage_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();


            con.ConnectionString = GetString.getconnectionString();

            #region insert in train
            string sql = "INSERT INTO Train(Tr_name,price,seatCapacity,A_serialNo,Tr_status) VALUES(@param1,@param2,@param3,@param4,@param5)";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.VarChar).Value = textBoxTR_name.Text;
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = int.Parse(textBoxTR_price.Text);
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(textBoxTR_seatCapacity.Text);

                cmd.Parameters.Add("@param4", SqlDbType.Int).Value = ad.id;

                cmd.Parameters.Add("@param5", SqlDbType.Int).Value = comboBoxTR_status.Text.ToString() == status.Active.ToString() ? 1 : 0;




                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();


              

                con.Close();
            }
            #endregion









            #region get train id

            SqlCommand command = new SqlCommand("select * from Train order by Tr_serialNo desc", con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            
            DR.Read();
            int id = int.Parse(DR[0].ToString());


            con.Close();


            #endregion










            #region insert in train endtime table


            string sql1 = "INSERT INTO Train_Station_EndTime(endTime,Tr_serialNo,S_serialNo) VALUES(@param1,@param2,@param3)";
            using (SqlCommand cmd = new SqlCommand(sql1, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Time).Value = dateTimePickerTR_et.Value.ToString("HH:mm");
                cmd.Parameters.Add("@param2", SqlDbType.Int).Value =id;

                cmd.Parameters.Add("@param3", SqlDbType.Int).Value =int.Parse( comboBoxTR_es.Text);




                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();


                con.Close();
            }

            #endregion


           #region insert in to train start time table

            string sql2 = "INSERT INTO Train_Station_StartTime(startTime,Tr_serialNo,S_serialNo) VALUES(@param1,@param2,@param3)";
            using (SqlCommand cmd = new SqlCommand(sql2, con))
            {

                con.Open();

                cmd.Parameters.Add("@param1", SqlDbType.Time).Value = dateTimePickerTR_st.Value.ToString("HH:mm");


                cmd.Parameters.Add("@param2", SqlDbType.Int).Value = id;

                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = int.Parse(comboBoxTR_ss.Text);






                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                MessageBox.Show("insert succesfully");

                con.Close();
            }

            #endregion






        }

        private void button4_Click(object sender, EventArgs e)
        {


            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            SqlCommand command = new SqlCommand("select Train.Tr_serialNo,Tr_name,price,seatCapacity,A_serialNo,Tr_status,Train_Station_StartTime.S_serialNo,Train_Station_EndTime.S_serialNo ,startTime,endTime from Train inner join Train_Station_StartTime on Train.Tr_serialNo=Train_Station_StartTime.Tr_serialNo inner join Train_Station_EndTime on Train.Tr_serialNo=Train_Station_EndTime.Tr_serialNo ", con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            BindingSource source = new BindingSource();
            source.DataSource = DR;


            dataGridViewTR.DataSource = source;


            con.Close();
        }

        private void dataGridViewTR_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
           
        }

        private void dataGridViewTR_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //textBoxTR_name.Text = dataGridViewTR.SelectedRows[0].Cells[1].Value.ToString();
            //textBoxTR_price.Text = dataGridViewTR.SelectedRows[0].Cells[2].Value.ToString();
            //textBoxTR_seatCapacity.Text = dataGridViewTR.SelectedRows[0].Cells[3].Value.ToString();
            //textBoxTR_serialNo.Text = dataGridViewTR.SelectedRows[0].Cells[0].Value.ToString();
            //comboBoxTR_status.Text = dataGridViewTR.SelectedRows[0].Cells[5].Value.ToString();
            //comboBoxTR_ss.Text = dataGridViewTR.SelectedRows[0].Cells[6].Value.ToString();
            //comboBoxTR_es.Text = dataGridViewTR.SelectedRows[0].Cells[7].Value.ToString();


        }

        private void textBoxTR_price_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxTR_status_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTR_seatCapacity_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            #region delete stattime by tr serial no


            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();


            string sql1 = "delete from Train_Station_StartTime where Tr_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql1, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxTR_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();


                con.Close();
            }

            #endregion





            #region delete endtime by tr serial no

            string sql2 = "delete from Train_Station_EndTime where Tr_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql2, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxTR_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("delete succesfully");


                con.Close();
            }

            #endregion


            #region delete train table by tr serialNo

            string sql = "delete from Train where Tr_serialNo=@param1";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();


                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = int.Parse(textBoxTR_serialNo.Text);



                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                


                con.Close();
            }
            #endregion







        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxTR_ss_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = GetString.getconnectionString();



            SqlCommand command = new SqlCommand("select S_serialNo,S_name from Station where S_status=1", con);


            con.Open();


            SqlDataReader DR = command.ExecuteReader();


            BindingSource source = new BindingSource();
            source.DataSource = DR;


            dataGridViewS.DataSource = source;


            con.Close();
        }

        private void dataGridViewTR_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridViewTR.Rows[e.RowIndex];


                textBoxTR_name.Text = row.Cells[1].Value.ToString();
                textBoxTR_price.Text = row.Cells[2].Value.ToString();
                textBoxTR_seatCapacity.Text = row.Cells[3].Value.ToString();
                textBoxTR_serialNo.Text = row.Cells[0].Value.ToString();
                comboBoxTR_status.Text = row.Cells[5].Value.ToString();
                comboBoxTR_ss.Text = row.Cells[6].Value.ToString();
                comboBoxTR_es.Text = row.Cells[7].Value.ToString();
                dateTimePickerTR_st.Value =DateTime.Parse( row.Cells[8].Value.ToString());
                dateTimePickerTR_et.Value = DateTime.Parse(row.Cells[8].Value.ToString());


            }
        }
    }
}
