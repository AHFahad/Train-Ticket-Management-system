﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Admin
{
    class GetString
    {
        public static string getconnectionString()
        {
            string a;
            a= "data source =DESKTOP-CGNASHS;" + "database = Railway_Management_System;" + "integrated security = SSPI";
            return a;
        }
    }
}
