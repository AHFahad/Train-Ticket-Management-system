﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class TicketClerkPage : Form
    {
        public int id;
        public TicketClerkPage(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BuyTicket a = new BuyTicket(this);
            this.Hide();
            a.Show();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            CancelTicket a = new CancelTicket(this);
            this.Hide();
            a.Show();
        }

        private void TicketClerkPage_Load(object sender, EventArgs e)
        {

        }
    }
}
