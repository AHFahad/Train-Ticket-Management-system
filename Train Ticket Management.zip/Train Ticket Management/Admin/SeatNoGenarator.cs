﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Admin
{
  public  class SeatNoGenarator
    {
        public static string SeatNo(int seatcount)
        {
            if (seatcount > 0 && seatcount <= 10)
            {
                return "A" + seatcount;
            }
            else if (seatcount > 10 && seatcount <= 20)
            {
                return "B" + seatcount;
            }
            else if (seatcount > 20 && seatcount <= 30)
            {
                return "C" + seatcount;
            }
            else if (seatcount > 30 && seatcount <= 40)
            {
                return "D" + seatcount;
            }
            else if (seatcount > 40 && seatcount <= 50)
            {
                return "E" + seatcount;
            }
            else if (seatcount > 50 && seatcount <= 60)
            {
                return "F" + seatcount;
            }
            else if (seatcount > 60 && seatcount <= 70)
            {
                return "G" + seatcount;
            }
            else if (seatcount > 70 && seatcount <= 80)
            {
                return "H" + seatcount;
            }
            else if (seatcount > 80 && seatcount <= 90)
            {
                return "I" + seatcount;
            }
            else if (seatcount > 90 && seatcount <= 100)
            {
                return "J" + seatcount;
            }
            else if (seatcount > 100 && seatcount <= 110)
            {
                return "K" + seatcount;
            }
            else if (seatcount > 110 && seatcount <= 120)
            {
                return "L" + seatcount;
            }
            
            return ""+seatcount;
        }
    }
}
