﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Train_Ticket_Management
{
    class Manage
    {
        Database db = new Database();

        public void CheckTicketClerk(LoginPage a, int id,string password)
        {

            
            Boolean check = db.CheckTicketClerk(id, password ,1);
           // return check;
            if (check == true)
            {
                Console.WriteLine("loged in  to clerk !!!!");
                a.Hide();
                //open ticket clerk window
                TicketClerkPage t = new TicketClerkPage(id);
                t.Show();

            }
            else MessageBox.Show("Wrong Password or ID");
        }

        public void CheckAdmin(LoginPage a, int id,string password)
        {
            
            Boolean check = db.CheckAdmin( id, password);
            //return check;
            if (check == true)
            {
                Console.WriteLine("loged in  to admin !!!!");
                a.Hide();
               //Open adminPage window
                Admin.AdminPage ad = new Admin.AdminPage(id);
                ad.Show();
            }
            else MessageBox.Show("Wrong Password or ID");
           
        }
    }
}
