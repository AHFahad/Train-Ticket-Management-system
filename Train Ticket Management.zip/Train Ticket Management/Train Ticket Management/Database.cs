﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Train_Ticket_Management
{
    class Database
    {
        public  Boolean CheckAdmin(int id,string password)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = "data source =DESKTOP-QAUH6FJ\\MSSQLSERVER01;" + "database = Railway_Management_System;" + "integrated security = SSPI";
            string sql = "SELECT  A_serialNo, A_password FROM Admin WHERE(A_serialNo = '"+id+"') AND(A_password = '"+password.Trim()+"')";

            SqlCommand commmand = new SqlCommand(sql, con);
            con.Open();

            var check = commmand.ExecuteScalar();

            if (check!=null)
            {
                return true;
            }
            else return false;
        }

        
        public  Boolean CheckTicketClerk(int id, string password,int status)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = "data source =DESKTOP-QAUH6FJ\\MSSQLSERVER01;" + "database = Railway_Management_System;" + "integrated security = SSPI";
            string sql = "SELECT  Tm_serialNo, Tm_status,tm_Password FROM Ticket_Man WHERE(Tm_serialNo = '" + id + "') AND(tm_Password = '" + password.Trim() + "')";

            SqlCommand commmand = new SqlCommand(sql, con);
            con.Open();

            var check = commmand.ExecuteScalar();

            if (check != null)
            {
                return true;
            }
            else return false;
        }

    }
}
