﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Train_Ticket_Management
{
    public partial class TicketClerkPage : Form
    {
        int id;
        public TicketClerkPage( int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void buyTicket1_Load(object sender, EventArgs e)
        {

        }

        private void buyTicket2_Load(object sender, EventArgs e)
        {

        }

        private void TicketClerkPage_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            cancelTicket.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buyTicket1.BringToFront();
        }

        private void cancelTicket_Load(object sender, EventArgs e)
        {

        }
    }
}
