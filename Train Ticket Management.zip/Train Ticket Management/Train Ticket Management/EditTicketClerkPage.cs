﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class EditTicketClerkPage : Form
    {
        public EditTicketClerkPage()
        {
            InitializeComponent();
        }

        private void edit_TicketClark1_Load(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPage a = new AdminPage();
            a.Show();
        }
    }
}
