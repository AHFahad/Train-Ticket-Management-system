﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Train_Ticket_Management
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Manage m = new Manage();
            if (rbtnTicketClerk.Checked)
            {
               m.CheckTicketClerk(this,int.Parse(inputID.Text.ToString().Trim()),inputPassword.Text.ToString().Trim());

            }
            else if(rbtnAdmin.Checked)
            {
                m.CheckAdmin(this,int.Parse(inputID.Text.ToString().Trim()), inputPassword.Text.ToString().Trim());
            }
            else
            {
                MessageBox.Show("please select a User");
            }
           
        }
    }
}
