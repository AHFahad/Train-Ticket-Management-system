﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Train_Ticket_Management
{
    public partial class BuyTicket : UserControl
    {
        public BuyTicket()
        {
            InitializeComponent();

            String[] searchBye = new string[] {"Stations","Train Number","Train Name"};
            comboBoxSearchBye.DataSource = searchBye;


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BuyTicket_Load(object sender, EventArgs e)
        {

        }

        private void comboBoxSearchBye_SelectedValueChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("selected value change ");
            if(comboBoxSearchBye.Text== "Stations")
            {
                groupBoxStations.Show();
                groupBoxName.Hide();
                groupBoxNumber.Hide();
            }

            else if(comboBoxSearchBye.Text== "Train Name")
            {
                groupBoxStations.Hide();
                groupBoxName.Show();
                groupBoxNumber.Hide();

            }
            else if(comboBoxSearchBye.Text== "Train Number")
            {
                groupBoxName.Hide();
                groupBoxNumber.Show();
                groupBoxStations.Hide();

            }
        }

        private void comboBoxSearchBye_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBoxNumber_Enter(object sender, EventArgs e)
        {

        }
    }
}
